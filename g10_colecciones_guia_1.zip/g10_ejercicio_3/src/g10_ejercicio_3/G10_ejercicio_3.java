/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package g10_ejercicio_3;

import servicio.AlumnoServicio;

/**
 *
 * @author jonak
 */
public class G10_ejercicio_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AlumnoServicio puente = new AlumnoServicio();
        
        puente.listaAlumnos();
        puente.notaFinal();

    }
    
}
