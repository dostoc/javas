/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import entidad.Alumno;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author jonak
 */
public class AlumnoServicio {
    
    /**
     * 3. Crear una clase llamada Alumno que mantenga información sobre las
     * notas de distintos alumnos. La clase Alumno tendrá como atributos, su
     * nombre y una lista de tipo Integer con sus 3 notas. 
     * 
     * En el servicio de
     * Alumno deberemos tener un bucle que crea un objeto Alumno. Se pide toda
     * la información al usuario y ese Alumno se guarda en una lista de tipo
     * Alumno y se le pregunta al usuario si quiere crear otro Alumno o no.
     * Después de ese bucle tendremos el siguiente método en el servicio de
     * Alumno: Método notaFinal(): El usuario ingresa el nombre del alumno que
     * quiere calcular su nota final y se lo busca en la lista de Alumnos. Si
     * está en la lista, se llama al método. Dentro del método se usará la lista
     * notas para calcular el promedio final de alumno. Siendo este promedio
     * final, devuelto por el método y mostrado en el main.
     */
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    ArrayList<Alumno> listaAlumno = new ArrayList();
    
    public Alumno crearAlumno(){
        int aux2;
        ArrayList<Integer> auxNotasList = new ArrayList();
        Alumno puente = new Alumno();
        System.out.print("Nombre:");
        puente.setNombre(leer.next());
        System.out.println("Notas: ");
        for (int i = 0; i < 3; i++) {
            auxNotasList.add(leer.nextInt());
        }
        puente.setNotas(auxNotasList);
    
        // otra forma de crear alumno
        // es hacer void
        // listaAlumno.add(new Alumno(nobre,auxNotasList)
        
        return puente;
    }
    
    public void listaAlumnos(){
        do {
            listaAlumno.add(this.crearAlumno());
            System.out.println("Desea cargar otro: s/n");
            if(leer.next().equalsIgnoreCase("n")){
                break;
            }
        } while (true);
    }
    
    public void notaFinal(){
        Iterator<Alumno> auxITE = listaAlumno.iterator();
        System.out.println("Ingrese nombre del alumno: ");
        String buscado = leer.next();
        int suma = 0;
        while (auxITE.hasNext()) {
            Alumno next = auxITE.next();
            if (next.getNombre().equals(buscado)) {
                for (int aux : next.getNotas()) {
                    suma = suma + aux;
                }
            }
        }
        System.out.println(buscado +" promedio: "+ (suma/3));
    }
}
