/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package g10_colecciones_guia_1;

import servicios.PerrosServicios;

/**
 *
 * @author jonak
 */
public class G10_colecciones_guia_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        PerrosServicios puente = new PerrosServicios();
        
        puente.agregarRazas();
        puente.mostrarRazas();

        puente.buscaRazaYeliminar();
        puente.mostrarRazas();
        
        
        

    }
    
}
