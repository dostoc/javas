/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import entidades.Perros;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author jonak
 */
public class PerrosServicios {

    ArrayList<Perros> tipo = new ArrayList<>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public Perros cargarRazas() {
        System.out.print("RAZA: ");
        String tipo = leer.next();

        return new Perros(tipo);
    }

    public void agregarRazas() {
        System.out.println("Ingrese razas: ");
        do {
            tipo.add(this.cargarRazas());
            System.out.println("Desea seguir (S/N)");
            if (leer.next().equalsIgnoreCase("N")) {
                break;
            }

        } while (true);

    }

    public void mostrarRazas() {
        for (Perros aux : tipo) {
            System.out.println(aux.toString());

        }
    }

    /**
     * 2. Continuando el ejercicio anterior, después de mostrar los perros, al
     * usuario se le pedirá un perro y se recorrerá la lista con un Iterator, se
     * buscará el perro en la lista. Si el perro está en la lista, se eliminará
     * el perro que ingresó el usuario y se mostrará la lista ordenada. Si el
     * perro no se encuentra en la lista, se le informará al usuario y se
     * mostrará la lista ordenada.
     *
     *
     */
    public void buscaRazaYeliminar() {
        
        Iterator<Perros> it = tipo.iterator();

        System.out.print("Ingrese una raza a quitar: ");
        String auxRaza = leer.next();
        boolean valid=false;
        while (it.hasNext()) {
            if (auxRaza.equalsIgnoreCase(it.next().getRazas())) {
                it.remove();
                valid = true;
            }
        }
        if (!(valid)) {
            System.out.println("La mascota no existe");
            
        }
    }
}


