/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author jonak
 */
public class Perros {
    
    private String razas;

    

    public Perros(String razas) {
        this.razas = razas;
    }

    public String getRazas() {
        return razas;
    }

    public void setRazas(String razas) {
        this.razas = razas;
    }
    
    
    @Override
    public String toString() {
        return "Mascota " + razas;
    }
    
    
}
