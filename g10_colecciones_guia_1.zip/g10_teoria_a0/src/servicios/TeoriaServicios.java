/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;

/**
 *
 * @author jonak
 */
public class TeoriaServicios {
    
    ArrayList<Integer> listado = new ArrayList();
    TreeSet<String> ejemplo = new TreeSet();
    HashMap<Integer,Integer> personas = new HashMap();
    
}
