/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package g10_ejercicio_1_2;

import servicio.RazaServicio;

/**
 *
 * @author jonak
 */
public class G10_ejercicio_1_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RazaServicio puente = new RazaServicio();
        
        puente.crearRaza();
        
        puente.buscarEliminar();
    }
    
}
