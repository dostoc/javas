/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author jonak
 */
public class RazaServicio {

    /**
     * 1. Diseñar un programa que lea y guarde razas de perros en un ArrayList
     * de tipo String. El programa pedirá una raza de perro en un bucle, el
     * mismo se guardará en la lista y después se le preguntará al usuario si
     * quiere guardar otro perro o si quiere salir. Si decide salir, se mostrará
     * todos los perros guardados en el ArrayList.
     *
     * 2. Continuando el ejercicio anterior, después de mostrar los perros, al
     * usuario se le pedirá un perro y se recorrerá la lista con un Iterator, se
     * buscará el perro en la lista. Si el perro está en la lista, se eliminará
     * el perro que ingresó el usuario y se mostrará la lista ordenada. Si el
     * perro no se encuentra en la lista, se le informará al usuario y se
     * mostrará la lista ordenada.
     */
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    ArrayList<String> RazasArray = new ArrayList();

    public void crearRaza() {
        do {
            System.out.println("Ingrese raza: ");
            RazasArray.add(leer.next());
            System.out.println("Salir s/n");
            if (leer.next().equalsIgnoreCase("s")) {
                break;
            }
        } while (true);

        for (String aux : RazasArray) {
            System.out.println(aux + " ");

        }
    }

    public void buscarEliminar() {
        System.out.println("Busqueda: ");
        System.out.println("------------------");
        String razaBuscada = leer.next();
        boolean existe = false;
        
        Iterator Ite = RazasArray.iterator();

        while (Ite.hasNext()) { // si el proximo existe
            if (Ite.next().equals(razaBuscada)) { // si es = a raza...
                Ite.remove(); // borrar
                existe = true;
            }
        }
        if (!(existe)) {
            System.out.println("La raza no existe");
        }
        System.out.println("Nueva Lista");
        for (String aux2 : RazasArray) {
            System.out.println(aux2);
        }

    }
}
