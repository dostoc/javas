/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import entidad.Pais;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;

/**
 *
 * @author jonak
 */
public class PaisServicio {
    
    /**
     * 5. Se requiere un programa que lea y guarde países, y para evitar que se
     * ingresen repetidos usaremos un conjunto. El programa pedirá un país en un
     * bucle, se guardará el país en el conjunto y después se le preguntará al
     * usuario si quiere guardar otro país o si quiere salir, si decide salir,
     * se mostrará todops los países guardados en el conjunto. (Recordemos hacer
     * los servicios en la clase correspondiente) Después deberemos mostrar el
     * conjunto ordenado alfabéticamente: para esto recordar cómo se ordena un
     * conjunto. Por último, al usuario se le pedirá un país y se recorrerá el
     * conjunto con un Iterator, se buscará el país en el conjunto y si está en
     * el conjunto se eliminará el país que ingresó el usuario y se mostrará el
     * conjunto. Si el país no se encuentra en el conjunto se le informará al
     * usuario.
     */
    private HashSet<Pais>conjuntoPais = new HashSet<Pais>();
    private String Pais;
    
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public void crearPais(){
        System.out.println("Ingrese Pais");
        conjuntoPais.add(Pais("Argentina"));
    
    
    }
    
    
}
