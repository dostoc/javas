/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

import java.util.HashSet;
import java.util.TreeSet;

/**
 *
 * @author jonak
 */
public class Pais {
    private String nombrePais;
    private HashSet <Pais> conjuntoPais;

    public Pais() {
    }

    public Pais(String nombrePais, HashSet<Pais> conjuntoPais) {
        this.nombrePais = nombrePais;
        this.conjuntoPais = conjuntoPais;
    }

    public String getNombrePais() {
        return nombrePais;
    }

    public void setNombrePais(String nombrePais) {
        this.nombrePais = nombrePais;
    }

    public HashSet<Pais> getConjuntoPais() {
        return conjuntoPais;
    }

    public void setConjuntoPais(HashSet<Pais> conjuntoPais) {
        this.conjuntoPais = conjuntoPais;
    }

    
            
            
}
