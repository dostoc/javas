/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package g10_ejercicio_4;

import java.util.ArrayList;
import java.util.Iterator;
import servicio.PeliculaServicio;

/**
 *
 * @author jonak
 */
public class G10_ejercicio_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PeliculaServicio puente = new PeliculaServicio();
        
        puente.crearLista();
        puente.mostarPeliculas();
        
        
        //System.out.println("Listado por interator");
        //puente.mostrarPeliculaHoraInterator();
        
        System.out.println("----------------------");
        System.out.println("Listado por forEach");
        puente.mostrarPeliculaHora();
        // TODO code application logic here
        
        puente.ordenarPelis();
        
        
    }
    
}
