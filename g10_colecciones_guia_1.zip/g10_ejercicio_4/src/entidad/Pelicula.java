/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

import java.util.Iterator;

/**
 *
 * @author jonak
 */
public class Pelicula {
    //Pelicula con el título,     * director y duración de la película (en horas)
    
    
    private String director;
    private String titulo;
    private Integer duracion;

    public Pelicula() {
    }

    public Pelicula(String director, String titulo, Integer duracion) {
        this.director = director;
        this.titulo = titulo;
        this.duracion = duracion;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Integer getDuracion() {
        return duracion;
    }

    public void setDuracion(Integer duracion) {
        this.duracion = duracion;
    }

    
    
    
    @Override
    public String toString() {
        return "Titulo: " + titulo + "Director: " + director+ "Duracion: " + duracion;
    }
    
    
    
            
    
    
    
    
    
    
    
    
}
