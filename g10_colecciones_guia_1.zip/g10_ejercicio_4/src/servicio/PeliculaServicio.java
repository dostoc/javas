/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import entidad.Pelicula;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author jonak
 */
public class PeliculaServicio {

    /**
     * 4. Un cine necesita implementar un sistema en el que se puedan cargar
     * peliculas. Para esto, tendremos una clase Pelicula con el título,
     * director y duración de la película (en horas). Implemente las clases y
     * métodos necesarios para esta situación, teniendo en cuenta lo que se pide
     * a continuación: En el servicio deberemos tener un bucle que crea un
     * objeto Pelicula pidiéndole al usuario todos sus datos y guardándolos en
     * el objeto Pelicula. Después, esa Pelicula se guarda una lista de
     * Peliculas y se le pregunta al usuario si quiere crear otra Pelicula o no.
     * Después de ese bucle realizaremos las siguientes acciones:
     *
     * 22
     *
     * • Mostrar en pantalla todas las películas. • Mostrar en pantalla todas *
     * las películas con una duración mayor a 1 hora. • Ordenar las películas de
     * * acuerdo a su duración (de mayor a menor) y mostrarlo en pantalla. •
     * Ordenar las películas de acuerdo a su duración (de menor a mayor) y
     * mostrarlo en pantalla. • Ordenar las películas por título,
     * alfabéticamente y mostrarlo en pantalla. • Ordenar las películas por
     * director, alfabéticamente y mostrarlo en pantalla.
     */
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    ArrayList<Pelicula> listaPelicula = new ArrayList();

    public Pelicula crearPelicula() {
        Pelicula puente = new Pelicula();
        System.out.print("Ingrese Titulo.....: ");
        puente.setTitulo(leer.next());
        System.out.print("Ingrese Director...: ");
        puente.setDirector(leer.next());
        System.out.print("Ingrese Duracion...: ");
        puente.setDuracion(leer.nextInt());
        return puente;
    }

    public void crearLista() {
        do {
            listaPelicula.add(this.crearPelicula());
            System.out.println("Desea salir s/n: ");
            if (leer.next().equalsIgnoreCase("s")) {
                break;
            }

        } while (true);
    }

    //Mostrar en pantalla todas las películas. 
    public void mostarPeliculas() {
        System.out.println("LISTADO DE PELICULAS:");
        for (Pelicula aux : listaPelicula) {
            System.out.println(aux);
        }
    }

    //Mostrar en pantalla todas * las películas con una duración mayor a 1 hora.
    // Iterator NO FUNCIONA CON 1 ·$%&/%$·" ???
    public void mostrarPeliculaHoraInterator() {
        //Para iterar un objeto se debebe definr Iterator<Objeto> ....
        Iterator<Pelicula> auxIterador = listaPelicula.iterator();
        System.out.println("Duracion minima de la pelicula (hrs): ");
        double duracionBuscada = leer.nextInt();
        while (auxIterador.hasNext()) {
            if (duracionBuscada < auxIterador.next().getDuracion()) {
                System.out.println(auxIterador.next());
            }
        }
    }

    // ForEach - se puede usar para mostrar editar pero no borrar debido
    // a que el recorrido que hace no puede ir variando (como que no dinamiza)
    public void mostrarPeliculaHora() {
        System.out.println("Duracion minima de la pelicula (hrs): ");
        double duracionBuscada = leer.nextInt();
        for (Pelicula aux : listaPelicula) {
            if (duracionBuscada < aux.getDuracion()) {
                System.out.println(aux);
            }
        }
    }

    // Ordenar las películas de acuerdo a su duración (de menor a mayor)
    // video https://www.youtube.com/watch?v=QXEoAFP5HNQ&list=PLgwlfcqa5h3xrtCyk4wz_U_OiBZWVhw2w&index=6
    // min 4
    public static Comparator<Pelicula> ordenarPorDuracion = new Comparator<Pelicula>() {
        @Override
        public int compare(Pelicula o1, Pelicula o2) {

            // return ! importante el no tiene que ser primitivo (int -> Ingeger)
            // sobrescribe la coleccion
            return o1.getDuracion().compareTo(o2.getDuracion());
        }
    };

    //Ordenar las películas por director, alfabéticamente y mostrarlo en pantalla.        
    public static Comparator<Pelicula> ordenarPorDirector = new Comparator<Pelicula>() {
        @Override
        public int compare(Pelicula o1, Pelicula o2) {
            return o1.getDirector().compareTo(o2.getDirector());
        }
    };

    //Ordenar las películas por título, alfabéticamente y mostrarlo en pantalla.
    public static Comparator<Pelicula> ordenarPorTitulo = new Comparator<Pelicula>() {
        @Override
        public int compare(Pelicula o1, Pelicula o2) {
            return o1.getTitulo().compareTo(o2.getTitulo());
        }
    };

    public void ordenarPelis() {
        System.out.println("POR DURACION---------------------------");
        Collections.sort(listaPelicula, this.ordenarPorDuracion);
        this.mostarPeliculas();
        System.out.println("POR TITULO-----------------------------");
        Collections.sort(listaPelicula, ordenarPorTitulo);
        this.mostarPeliculas();
        System.out.println("POR DIRECTOR---------------------------");
        Collections.sort(listaPelicula, ordenarPorDirector);
        this.mostarPeliculas();
    }

}
